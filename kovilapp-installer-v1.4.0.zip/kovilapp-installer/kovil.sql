-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 09, 2025 at 03:21 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kovil`
--

-- --------------------------------------------------------

--
-- Table structure for table `attachments`
--

CREATE TABLE `attachments` (
  `id` int(50) NOT NULL,
  `m_id` int(20) NOT NULL,
  `type` text NOT NULL,
  `file_name` varchar(50) NOT NULL,
  `path` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `child`
--

CREATE TABLE `child` (
  `id` int(11) NOT NULL,
  `fam_id` int(11) NOT NULL,
  `c_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `father_id` int(11) NOT NULL,
  `c_image` varchar(100) NOT NULL,
  `c_dob` date DEFAULT NULL,
  `c_gender` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `c_blood_group` varchar(70) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `c_marital_status` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `c_qualification` varchar(90) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `c_mobile_no` varchar(25) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `c_email` varchar(70) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `c_occupation` varchar(70) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `c_created_by` varchar(70) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `c_created_date` varchar(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `c_lastmodified_by` varchar(70) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `c_lastmodified_date` varchar(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `c_education_details` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `c_occupation_details` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `family`
--

CREATE TABLE `family` (
  `id` int(11) NOT NULL,
  `member_no` int(11) DEFAULT NULL,
  `member_id` varchar(20) DEFAULT NULL,
  `parent_id` int(20) DEFAULT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `app_front` varchar(200) DEFAULT NULL,
  `app_back` varchar(100) DEFAULT NULL,
  `family_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `father_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `mother_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `dob_old` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `age` int(20) DEFAULT NULL,
  `blood_group` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `qualification` int(11) DEFAULT NULL,
  `education_details` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `occupation` int(11) DEFAULT NULL,
  `occupation_details` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `email` varchar(80) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `pudavai` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile_no` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `image` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `permanent_address` text CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `current_address` text CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `village` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `taluk` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `district` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `state` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `c_pincode` varchar(255) DEFAULT NULL,
  `c_state` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `c_village` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `c_taluk` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `c_district` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `c_country` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `kattalai` int(11) DEFAULT NULL,
  `k_village` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `w_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `ic` varchar(100) DEFAULT NULL,
  `w_dob_old` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `w_dob` date DEFAULT NULL,
  `w_blood_group` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `w_qualification` int(11) DEFAULT NULL,
  `w_occupation` int(11) DEFAULT NULL,
  `w_kootam` int(11) DEFAULT NULL,
  `w_kootam_old` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `w_temple` varchar(80) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `w_email` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `w_image` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_by` bigint(50) DEFAULT NULL,
  `created_date_old` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `appback` varchar(200) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `admin_notes` text CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `_2000_bk_no` int(100) DEFAULT NULL,
  `_2000_rc_no` int(100) DEFAULT NULL,
  `member_name` varchar(50) DEFAULT NULL,
  `join_date` varchar(23) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `w_education_details` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `w_occupation_details` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `kattam`
--

CREATE TABLE `kattam` (
  `id` int(50) NOT NULL,
  `m_id` int(11) NOT NULL,
  `a_sevvai` int(11) NOT NULL,
  `a_sooriyan` int(11) NOT NULL,
  `a_chandran` int(11) NOT NULL,
  `a_budhan` int(11) NOT NULL,
  `a_guru` int(11) NOT NULL,
  `a_raaghu` int(11) NOT NULL,
  `a_kaedhu` int(11) NOT NULL,
  `a_sani` int(11) NOT NULL,
  `a_sukkiran` int(11) NOT NULL,
  `a_laknam` int(10) NOT NULL,
  `r_sevvai` int(10) NOT NULL,
  `r_sooriyan` int(10) NOT NULL,
  `r_chandran` int(10) NOT NULL,
  `r_budhan` int(10) NOT NULL,
  `r_guru` int(10) NOT NULL,
  `r_raaghu` int(10) NOT NULL,
  `r_kaedhu` int(10) NOT NULL,
  `r_sani` int(10) NOT NULL,
  `r_sukkiran` int(10) NOT NULL,
  `r_laknam` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `labels`
--

CREATE TABLE `labels` (
  `id` int(10) NOT NULL,
  `display_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(40) NOT NULL,
  `type` int(11) NOT NULL DEFAULT 0,
  `category` varchar(20) NOT NULL,
  `parent_id` int(20) DEFAULT NULL,
  `order` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `matrimony`
--

CREATE TABLE `matrimony` (
  `id` int(15) NOT NULL,
  `reg_no` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `father_name` varchar(25) NOT NULL,
  `mother_name` varchar(25) NOT NULL,
  `gender` varchar(25) NOT NULL,
  `age` int(5) NOT NULL,
  `birth_date` date NOT NULL,
  `birth_time` time NOT NULL,
  `birth_place` varchar(25) NOT NULL,
  `raasi` varchar(25) NOT NULL,
  `star` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `laknam` varchar(25) NOT NULL,
  `raaghu_kaedhu` varchar(25) NOT NULL,
  `padham` varchar(25) NOT NULL,
  `sevvai` varchar(25) NOT NULL,
  `kulam` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `temple` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `m_kulam` varchar(23) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `mm_kulam` varchar(23) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `pm_kulam` varchar(23) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `height` int(10) NOT NULL,
  `weight` int(11) NOT NULL,
  `colour` text NOT NULL,
  `blood_group` varchar(10) NOT NULL,
  `qualification` varchar(25) NOT NULL,
  `education_details` varchar(100) NOT NULL,
  `college_details` varchar(100) NOT NULL,
  `occupation` varchar(25) NOT NULL,
  `occupation_details` varchar(100) NOT NULL,
  `income` varchar(15) NOT NULL,
  `asset_details` varchar(255) NOT NULL,
  `email` varchar(30) NOT NULL,
  `mobile_no` varchar(15) NOT NULL,
  `contact_person` varchar(255) NOT NULL,
  `relationship` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `referred_by` varchar(20) NOT NULL,
  `ref_id` bigint(20) NOT NULL,
  `country` varchar(100) NOT NULL,
  `sibling` varchar(25) NOT NULL,
  `f_occupation` varchar(25) NOT NULL,
  `registered_date` date NOT NULL,
  `marital_status` varchar(10) NOT NULL,
  `m_occupation` varchar(25) NOT NULL,
  `about_myself` varchar(100) NOT NULL,
  `admin_notes` text NOT NULL,
  `photo` varchar(20) NOT NULL,
  `horo` varchar(30) NOT NULL,
  `status` varchar(10) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `close_reason_code` int(11) NOT NULL,
  `married_to` int(11) NOT NULL,
  `close_reason_detail` varchar(255) NOT NULL,
  `pp_education` varchar(255) NOT NULL,
  `pp_occupation` varchar(255) NOT NULL,
  `pp_work_location` varchar(255) NOT NULL,
  `pp_salary` varchar(255) NOT NULL,
  `pp_expectation` text NOT NULL,
  `pp_asset_details` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `member_subscriptions`
--

CREATE TABLE `member_subscriptions` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_date` date NOT NULL,
  `book_id` int(11) NOT NULL,
  `receipt_no` int(11) NOT NULL,
  `address` text DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `status` enum('paid','pending','cancelled') NOT NULL DEFAULT 'paid',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `receipt_books`
--

CREATE TABLE `receipt_books` (
  `id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `book_no` int(11) NOT NULL,
  `book_type` enum('fixed','generic') NOT NULL DEFAULT 'generic',
  `issued_to` varchar(255) DEFAULT NULL,
  `start_receipt_no` int(11) NOT NULL,
  `end_receipt_no` int(11) NOT NULL,
  `denomination` varchar(100) DEFAULT NULL,
  `status` enum('active','completed','cancelled') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `receipt_details`
--

CREATE TABLE `receipt_details` (
  `id` int(11) NOT NULL,
  `subscription_id` int(11) NOT NULL,
  `receipt_no` int(11) NOT NULL,
  `book_no` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` enum('cash','cheque','online','other') DEFAULT 'cash',
  `cheque_no` varchar(50) DEFAULT NULL,
  `bank_name` varchar(100) DEFAULT NULL,
  `issued_by` varchar(255) DEFAULT NULL,
  `issued_date` date NOT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subscription_events`
--

CREATE TABLE `subscription_events` (
  `id` int(11) NOT NULL,
  `event_name` varchar(255) NOT NULL,
  `event_type` enum('membership','annual','donation','special_event') NOT NULL,
  `total_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` enum('open','closed') NOT NULL DEFAULT 'open',
  `date` date NOT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trash`
--

CREATE TABLE `trash` (
  `trash_files` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(11) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` varchar(100) NOT NULL,
  `profile_id` varchar(100) NOT NULL,
  `creation_date` varchar(100) NOT NULL,
  `created_by` varchar(100) NOT NULL,
  `u_image` varchar(255) NOT NULL,
  `mobile_no` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attachments`
--
ALTER TABLE `attachments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `child`
--
ALTER TABLE `child`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `family`
--
ALTER TABLE `family`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kattam`
--
ALTER TABLE `kattam`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `labels`
--
ALTER TABLE `labels`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `matrimony`
--
ALTER TABLE `matrimony`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `member_subscriptions`
--
ALTER TABLE `member_subscriptions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_member_id` (`member_id`),
  ADD KEY `idx_event_id` (`event_id`),
  ADD KEY `idx_book_id` (`book_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_payment_date` (`payment_date`),
  ADD KEY `idx_member_event` (`member_id`,`event_id`);

--
-- Indexes for table `receipt_books`
--
ALTER TABLE `receipt_books`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_event_book` (`event_id`,`book_no`),
  ADD KEY `idx_event_id` (`event_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_book_type` (`book_type`);

--
-- Indexes for table `receipt_details`
--
ALTER TABLE `receipt_details`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_book_receipt` (`book_no`,`receipt_no`),
  ADD KEY `idx_subscription_id` (`subscription_id`),
  ADD KEY `idx_issued_date` (`issued_date`);

--
-- Indexes for table `subscription_events`
--
ALTER TABLE `subscription_events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_event_type` (`event_type`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_date` (`date`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attachments`
--
ALTER TABLE `attachments`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `child`
--
ALTER TABLE `child`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `family`
--
ALTER TABLE `family`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `kattam`
--
ALTER TABLE `kattam`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `labels`
--
ALTER TABLE `labels`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `matrimony`
--
ALTER TABLE `matrimony`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `member_subscriptions`
--
ALTER TABLE `member_subscriptions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `receipt_books`
--
ALTER TABLE `receipt_books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `receipt_details`
--
ALTER TABLE `receipt_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subscription_events`
--
ALTER TABLE `subscription_events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `member_subscriptions`
--
ALTER TABLE `member_subscriptions`
  ADD CONSTRAINT `member_subscriptions_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `family` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `member_subscriptions_ibfk_2` FOREIGN KEY (`event_id`) REFERENCES `subscription_events` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `member_subscriptions_ibfk_3` FOREIGN KEY (`book_id`) REFERENCES `receipt_books` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `receipt_books`
--
ALTER TABLE `receipt_books`
  ADD CONSTRAINT `receipt_books_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `subscription_events` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `receipt_details`
--
ALTER TABLE `receipt_details`
  ADD CONSTRAINT `receipt_details_ibfk_1` FOREIGN KEY (`subscription_id`) REFERENCES `member_subscriptions` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
