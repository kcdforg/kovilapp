-- Migration script to add address column to member_subscriptions table
-- Run this script on your existing database

-- Add address column to member_subscriptions table
ALTER TABLE `member_subscriptions` ADD COLUMN `address` text AFTER `receipt_no`;

-- Update existing records to have empty address (optional)
-- UPDATE `member_subscriptions` SET `address` = '' WHERE `address` IS NULL; 