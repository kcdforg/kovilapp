-- Subscription Module Database Structure
-- For Kovil App - Modern Version

-- 1. Subscription Events Table
-- Stores different types of subscription events (Membership, Annual, Donation, Special Events)
CREATE TABLE IF NOT EXISTS `subscription_events` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `event_name` varchar(255) NOT NULL,
    `event_type` enum('membership', 'annual', 'donation', 'special_event') NOT NULL,
    `total_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
    `status` enum('open', 'closed') NOT NULL DEFAULT 'open',
    `date` date NOT NULL,
    `remarks` text,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_event_type` (`event_type`),
    KEY `idx_status` (`status`),
    KEY `idx_date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Receipt Books Table
-- Stores receipt books for each subscription event
CREATE TABLE IF NOT EXISTS `receipt_books` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `event_id` int(11) NOT NULL,
    `book_no` int(11) NOT NULL,
    `book_type` enum('fixed', 'generic') NOT NULL DEFAULT 'generic',
    `issued_to` varchar(255),
    `start_receipt_no` int(11) NOT NULL,
    `end_receipt_no` int(11) NOT NULL,
    `denomination` varchar(100),
    `status` enum('active', 'completed', 'cancelled') NOT NULL DEFAULT 'active',
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_event_book` (`event_id`, `book_no`),
    KEY `idx_event_id` (`event_id`),
    KEY `idx_status` (`status`),
    KEY `idx_book_type` (`book_type`),
    FOREIGN KEY (`event_id`) REFERENCES `subscription_events`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Member Subscriptions Table
-- Links members to subscription events with payment details
CREATE TABLE IF NOT EXISTS `member_subscriptions` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `member_id` int(11) NOT NULL,
    `event_id` int(11) NOT NULL,
    `amount` decimal(10,2) NOT NULL,
    `payment_date` date NOT NULL,
    `book_id` int(11) NOT NULL,
    `receipt_no` int(11) NOT NULL,
    `address` text,
    `remarks` text,
    `status` enum('paid', 'pending', 'cancelled') NOT NULL DEFAULT 'paid',
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_member_id` (`member_id`),
    KEY `idx_event_id` (`event_id`),
    KEY `idx_book_id` (`book_id`),
    KEY `idx_status` (`status`),
    KEY `idx_payment_date` (`payment_date`),
    FOREIGN KEY (`member_id`) REFERENCES `family`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`event_id`) REFERENCES `subscription_events`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`book_id`) REFERENCES `receipt_books`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Receipt Details Table (Optional - for detailed receipt tracking)
-- Stores individual receipt details for audit purposes
CREATE TABLE IF NOT EXISTS `receipt_details` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `subscription_id` int(11) NOT NULL,
    `receipt_no` int(11) NOT NULL,
    `book_no` int(11) NOT NULL,
    `amount` decimal(10,2) NOT NULL,
    `payment_method` enum('cash', 'cheque', 'online', 'other') DEFAULT 'cash',
    `cheque_no` varchar(50),
    `bank_name` varchar(100),
    `issued_by` varchar(255),
    `issued_date` date NOT NULL,
    `remarks` text,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_book_receipt` (`book_no`, `receipt_no`),
    KEY `idx_subscription_id` (`subscription_id`),
    KEY `idx_issued_date` (`issued_date`),
    FOREIGN KEY (`subscription_id`) REFERENCES `member_subscriptions`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sample Data for Testing

-- Insert sample subscription events
INSERT INTO `subscription_events` (`event_name`, `event_type`, `total_amount`, `status`, `date`, `remarks`) VALUES
('Annual Membership Fee 2024', 'membership', 500.00, 'open', '2024-01-01', 'Mandatory annual membership fee for all members'),
('Annual Subscription 2024', 'annual', 1000.00, 'open', '2024-01-01', 'Annual subscription fee for temple activities'),
('Temple Donation Drive', 'donation', 0.00, 'open', '2024-01-15', 'Voluntary donation drive for temple maintenance'),
('Cultural Festival 2024', 'special_event', 200.00, 'open', '2024-02-01', 'Special event participation fee');

-- Insert sample receipt books
INSERT INTO `receipt_books` (`event_id`, `book_no`, `book_type`, `issued_to`, `start_receipt_no`, `end_receipt_no`, `denomination`, `status`) VALUES
(1, 1, 'fixed', 'Admin', 1, 100, '500.00', 'active'),
(1, 2, 'fixed', 'Admin', 101, 200, '500.00', 'active'),
(2, 1, 'fixed', 'Admin', 1, 100, '1000.00', 'active'),
(3, 1, 'generic', 'Admin', 1, 100, '', 'active'),
(4, 1, 'fixed', 'Admin', 1, 50, '200.00', 'active');

-- Sample member subscriptions (assuming family table has members with IDs 1, 2, 3)
-- Note: These will work only if the family table has these IDs
INSERT INTO `member_subscriptions` (`member_id`, `event_id`, `amount`, `payment_date`, `book_id`, `receipt_no`, `remarks`, `status`) VALUES
(1, 1, 500.00, '2024-01-05', 1, 1, 'Annual membership payment', 'paid'),
(2, 1, 500.00, '2024-01-06', 1, 2, 'Annual membership payment', 'paid'),
(3, 2, 1000.00, '2024-01-10', 3, 1, 'Annual subscription payment', 'paid'),
(1, 3, 100.00, '2024-01-20', 4, 1, 'Donation for temple maintenance', 'paid'),
(2, 4, 200.00, '2024-02-05', 5, 1, 'Cultural festival participation', 'paid');

-- Sample receipt details
INSERT INTO `receipt_details` (`subscription_id`, `receipt_no`, `book_no`, `amount`, `payment_method`, `issued_by`, `issued_date`, `remarks`) VALUES
(1, 1, 1, 500.00, 'cash', 'Admin', '2024-01-05', 'Annual membership payment'),
(2, 2, 1, 500.00, 'cash', 'Admin', '2024-01-06', 'Annual membership payment'),
(3, 1, 3, 1000.00, 'cash', 'Admin', '2024-01-10', 'Annual subscription payment'),
(4, 1, 4, 100.00, 'cash', 'Admin', '2024-01-20', 'Donation for temple maintenance'),
(5, 1, 5, 200.00, 'cash', 'Admin', '2024-02-05', 'Cultural festival participation');

-- Indexes for better performance
CREATE INDEX `idx_subscription_events_type_status` ON `subscription_events` (`event_type`, `status`);
CREATE INDEX `idx_member_subscriptions_member_event` ON `member_subscriptions` (`member_id`, `event_id`);
CREATE INDEX `idx_receipt_books_event_status` ON `receipt_books` (`event_id`, `status`);
CREATE INDEX `idx_receipt_details_subscription` ON `receipt_details` (`subscription_id`);

-- Views for easier querying

-- View: Active Events Summary
CREATE OR REPLACE VIEW `v_active_events_summary` AS
SELECT 
    se.id,
    se.event_name,
    se.event_type,
    se.total_amount,
    se.status,
    se.date,
    COUNT(rb.id) as total_books,
    COUNT(ms.id) as total_payments,
    COALESCE(SUM(ms.amount), 0) as collected_amount
FROM subscription_events se
LEFT JOIN receipt_books rb ON se.id = rb.event_id AND rb.status = 'active'
LEFT JOIN member_subscriptions ms ON se.id = ms.event_id AND ms.status = 'paid'
WHERE se.status = 'open'
GROUP BY se.id;

-- View: Member Payment Summary
CREATE OR REPLACE VIEW `v_member_payment_summary` AS
SELECT 
    f.id as member_id,
    f.name as member_name,
    f.mobile as member_mobile,
    se.event_name,
    se.event_type,
    ms.amount,
    ms.payment_date,
    rb.book_no,
    ms.receipt_no,
    ms.status
FROM family f
JOIN member_subscriptions ms ON f.id = ms.member_id
JOIN subscription_events se ON ms.event_id = se.id
JOIN receipt_books rb ON ms.book_id = rb.id
ORDER BY ms.payment_date DESC;

-- View: Receipt Book Status
CREATE OR REPLACE VIEW `v_receipt_book_status` AS
SELECT 
    rb.id,
    rb.event_id,
    se.event_name,
    rb.book_no,
    rb.start_receipt_no,
    rb.end_receipt_no,
    rb.status,
    COUNT(ms.id) as used_receipts,
    (rb.end_receipt_no - rb.start_receipt_no + 1) as total_receipts,
    ((rb.end_receipt_no - rb.start_receipt_no + 1) - COUNT(ms.id)) as available_receipts
FROM receipt_books rb
JOIN subscription_events se ON rb.event_id = se.id
LEFT JOIN member_subscriptions ms ON rb.id = ms.book_id
GROUP BY rb.id; 