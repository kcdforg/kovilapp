-- Remove unique constraint to allow multiple payments from same member
-- Run this script if you have an existing database with the uk_member_event constraint

-- Drop the unique constraint that prevents multiple payments from same member
ALTER TABLE `member_subscriptions` 
DROP INDEX `uk_member_event`;

-- Add a composite index for better performance (non-unique)
ALTER TABLE `member_subscriptions` 
ADD INDEX `idx_member_event` (`member_id`, `event_id`);

-- Note: This allows multiple payments from the same member for the same event
-- Receipt number uniqueness is still enforced per book 