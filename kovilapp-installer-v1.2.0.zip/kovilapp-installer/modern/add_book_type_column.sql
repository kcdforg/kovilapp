-- Add book_type column to existing receipt_books table
-- Run this script if you have an existing database without the book_type column

-- Add the book_type column
ALTER TABLE `receipt_books` 
ADD COLUMN `book_type` enum('fixed', 'generic') NOT NULL DEFAULT 'generic' 
AFTER `book_no`;

-- Add index for better performance
ALTER TABLE `receipt_books` 
ADD INDEX `idx_book_type` (`book_type`);

-- Update existing records to set book_type based on denomination
-- If denomination is not empty, set as 'fixed', otherwise 'generic'
UPDATE `receipt_books` 
SET `book_type` = CASE 
    WHEN `denomination` IS NOT NULL AND `denomination` != '' AND `denomination` != 'Variable' 
    THEN 'fixed' 
    ELSE 'generic' 
END;

-- Clear denomination for generic books
UPDATE `receipt_books` 
SET `denomination` = '' 
WHERE `book_type` = 'generic'; 