<?php
require(dirname(__FILE__)."/config.php");
require(dirname(__FILE__)."/vars.php");
include_once(dirname(__FILE__)."/function.php");

connectdb();
?>